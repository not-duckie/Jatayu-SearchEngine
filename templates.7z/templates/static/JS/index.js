$(document).ready(function(){

$("#privacy").click(function(){
  $("#none1").toggle(70);
});

$("#social").click(function(){
  $("#none2").toggle(70);
});

$("#menu").click(function(){
  $("#none3").toggle(100);
});

$("#close").click(function(){
  $("#none3").toggle(100);
});

	
});
